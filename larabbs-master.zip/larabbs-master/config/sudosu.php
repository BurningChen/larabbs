<?php

return [

    // 允许使用的顶级域名
    'allowed_tlds' => ['dev', 'local', 'app', 'test'],

    // 用户模型
    'user_model' => App\Models\User::class

];